<?php
/**
 * index.php - logecho-main
 * 
 * @author joyqi
 */

require_once 'vendor/autoload.php';
le_do_workflow('main.run');

